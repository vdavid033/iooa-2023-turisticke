<template>
  <h1>{{ trenutniID }}</h1>

</template>

<script setup>

import { ref, onMounted } from "vue"
import {api} from 'boot/axios'
import { useRoute, useRouter } from 'vue-router';

const posts = ref([])
const route = useRoute()
const router = useRouter()

const trenutniID = route.params.id

const getPosts = async () => {
  try{
    const response = await api.get(`/atrakcije/${trenutniID}`)
    posts.value = response.data

    console.log("ID je: " , trenutniID)
    console.log("Podatak iz baze po ID: " , posts.value)


  }catch (error){
    console.log(error)
  }
}

onMounted(() => {
  getPosts()
})

</script>



<style scoped>
.bg-blue {
  background-color: #1e90ff;
}

.q-truncate {
  max-width: 600px;
}

.container {
  display: grid;
  align-items: center;
  grid-template-columns: 1fr 1fr 1fr;
  column-gap: 5px;
}
</style>
